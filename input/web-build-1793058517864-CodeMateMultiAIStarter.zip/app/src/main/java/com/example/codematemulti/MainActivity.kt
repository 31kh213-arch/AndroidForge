package com.example.codematemulti
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity:Activity(){
 private val bg=Color.rgb(13,17,23); private val panel=Color.rgb(22,27,34); private val ink=Color.rgb(235,241,248); private val accent=Color.rgb(91,156,255)
 private lateinit var content:LinearLayout; private lateinit var status:TextView
 private var provider="OpenRouter"; private var endpoint="https://openrouter.ai/api/v1/chat/completions"; private var model="openai/gpt-4o-mini"; private var key=""
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  val p=getSharedPreferences("settings",0); provider=p.getString("provider",provider)!!; endpoint=p.getString("endpoint",endpoint)!!; model=p.getString("model",model)!!; key=p.getString("key","")!!
  val root=LinearLayout(this).apply{orientation=1;setPadding(16,18,16,14);setBackgroundColor(bg)}
  root.addView(TextView(this).apply{text="CodeMate AI";textSize=26f;setTextColor(ink);typeface=Typeface.DEFAULT_BOLD})
  root.addView(TextView(this).apply{text="MULTI-MODEL CODING WORKSPACE";textSize=11f;setTextColor(accent);setPadding(0,0,0,10)})
  val nav=LinearLayout(this); nav.addView(btn("Chat"){chat()},lp());nav.addView(btn("Code"){code()},lp());nav.addView(btn("Models"){settings()},lp());root.addView(nav)
  status=TextView(this).apply{text="Ready • Configure your provider";setTextColor(Color.LTGRAY);setPadding(2,8,2,8)};root.addView(status)
  content=LinearLayout(this).apply{orientation=1};root.addView(content,LinearLayout.LayoutParams(-1,0,1f));setContentView(root);chat()
 }
 private fun lp()=LinearLayout.LayoutParams(0,46,1f).apply{setMargins(3,3,3,3)}
 private fun btn(s:String,a:()->Unit)=Button(this).apply{text=s;isAllCaps=false;setTextColor(ink);setBackgroundColor(panel);setOnClickListener{a()}}
 private fun label(s:String,n:Float=14f)=TextView(this).apply{text=s;textSize=n;setTextColor(ink);setPadding(0,7,0,7)}
 private fun field(h:String,v:String="",multi:Boolean=false)=EditText(this).apply{hint=h;setText(v);setTextColor(ink);setHintTextColor(Color.GRAY);setBackgroundColor(panel);setPadding(12,9,12,9);if(multi){minLines=8;gravity=Gravity.TOP;typeface=Typeface.MONOSPACE}}
 private fun chat(){content.removeAllViews();content.addView(label("Ask any connected AI to write or debug code.",15f))
  val transcript=TextView(this).apply{text="Welcome to CodeMate.\n\nSet up a provider in Models. OpenRouter can route to multiple model families using one compatible endpoint. You need your own provider API key.";setTextColor(ink);textSize=15f;setPadding(12,12,12,12);setBackgroundColor(panel)}
  content.addView(ScrollView(this).apply{addView(transcript)},LinearLayout.LayoutParams(-1,0,1f))
  val prompt=field("Describe the app or code you need…",multi=true).apply{minLines=3;maxLines=5};content.addView(prompt)
  content.addView(btn("Send to AI"){val q=prompt.text.toString().trim();if(q.isEmpty())return@btn;transcript.append("\n\nYOU:\n$q\n\n");prompt.setText("")
   if(endpoint.isBlank()||model.isBlank()){transcript.append("Configure endpoint and model in Models.");return@btn}
   status.text="Thinking…";thread{val answer=ask(q);runOnUiThread{transcript.append("AI ($provider / $model):\n$answer\n\n");status.text="Ready"}}
  })
 }
 private fun code(){content.removeAllViews();content.addView(label("Code scratchpad",19f));content.addView(label("Write or paste code, then copy it. This starter is not an on-device APK compiler."))
  val e=field("Your code…",multi=true).apply{minLines=12;typeface=Typeface.MONOSPACE};content.addView(e,LinearLayout.LayoutParams(-1,0,1f))
  content.addView(btn("Copy code"){val cb=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager;cb.setPrimaryClip(android.content.ClipData.newPlainText("code",e.text.toString()));status.text="Copied"})
 }
 private fun settings(){content.removeAllViews();content.addView(label("AI provider settings",19f))
  val choices=listOf("OpenRouter","OpenAI-compatible","OpenAI","Claude via compatible gateway","Gemini via compatible gateway","Custom")
  val sp=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,choices);setSelection(choices.indexOf(provider).coerceAtLeast(0))};content.addView(label("Provider / gateway"));content.addView(sp)
  val ep=field("Full chat-completions endpoint URL",endpoint);val mo=field("Model ID",model);val ky=field("API key",key).apply{inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD}
  content.addView(label("Endpoint"));content.addView(ep);content.addView(label("Model ID"));content.addView(mo);content.addView(label("API key"));content.addView(ky)
  content.addView(btn("Save settings"){provider=sp.selectedItem.toString();endpoint=ep.text.toString().trim();model=mo.text.toString().trim();key=ky.text.toString().trim()
   getSharedPreferences("settings",0).edit().putString("provider",provider).putString("endpoint",endpoint).putString("model",model).putString("key",key).apply();status.text="Saved $provider";Toast.makeText(this,"Settings saved",0).show()})
  content.addView(label("This client sends OpenAI-compatible chat-completions requests. Native Claude and Gemini APIs need different request/authentication code; use a compatible gateway or adapt the client."))
  content.addView(label("API keys are stored locally for testing. Never embed a shared secret in an APK you distribute."))
 }
 private fun ask(q:String):String=try{
  val c=URL(endpoint).openConnection() as HttpURLConnection;c.requestMethod="POST";c.connectTimeout=20000;c.readTimeout=60000;c.doOutput=true;c.setRequestProperty("Content-Type","application/json");if(key.isNotBlank())c.setRequestProperty("Authorization","Bearer $key")
  val body=JSONObject().put("model",model).put("messages",JSONArray().put(JSONObject().put("role","system").put("content","You are a careful coding assistant. Provide useful code and concise explanations.")).put(JSONObject().put("role","user").put("content",q))).put("temperature",0.3)
  c.outputStream.use{it.write(body.toString().toByteArray(Charsets.UTF_8))};val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream;val raw=stream.bufferedReader().use{it.readText()}
  if(code !in 200..299)"HTTP $code: $raw" else JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
 }catch(e:Exception){"Request failed: ${e.message}\nCheck the endpoint, model ID, API key, network, and API compatibility."}
}
