# CodeMate AI — multi-model Android starter

Features: native Kotlin chat UI, code scratchpad with copy, provider/model/endpoint settings, and API-key setting.

Default route uses OpenRouter's OpenAI-compatible chat-completions endpoint. Set a model ID supported by your account. Other providers work only if they accept the same request/response format; native Claude and Gemini APIs require adapting the network client.

## Build
Open in Android Studio, sync Gradle, then choose Build > Build APK(s). Debug APK output is usually `app/build/outputs/apk/debug/`.

This is source code, not a compiled APK. The app does not bypass provider limits. Usage and charges depend on the provider/model. Keys are stored locally for development only; a production app should call your backend rather than ship secrets.
